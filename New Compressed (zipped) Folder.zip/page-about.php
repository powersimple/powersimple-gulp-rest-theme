<?php
get_header(); ?>
  <!-- UI, for draggable nodes -->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/jquery-ui.min.js"></script>

  <!-- Raphael for SVG support (won't work on android) -->
	<script type="text/javascript" src="//powersimple.192.168.1.11.xip.io:3000/wp-content/themes/powersimple/app/js/vendor/raphael.min.js"></script>

  <!-- Mindmap -->
	<script type="text/javascript" src="//powersimple.192.168.1.11.xip.io:3000/wp-content/themes/powersimple/app/js/vendor/mindmap.js"></script>


<?php
get_footer(); ?>
