<?php
/**
 * Theme Name: Powersimple
 * Because they said this file was necessary for  standalone theme, so ok.
 */

